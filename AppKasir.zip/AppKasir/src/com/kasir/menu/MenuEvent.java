package com.kasir.menu;

import com.kasir.menu.*;

public interface MenuEvent {

    public void menuSelected(int index, int subIndex, MenuAction action);
}
